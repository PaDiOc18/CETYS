﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using Path = System.IO.Path;
using Newtonsoft.Json;

namespace final
{
    /// <summary>
    /// Interaction logic for Upload.xaml
    /// </summary>
    public partial class Upload : Window
    {
        bool verify = true;

        List<Post> Posts;
        User CurrentUser;
        List<User> users;
        public Upload(List<Post> Posts, User CurrentUser, List<User> users)
        {
            InitializeComponent();
            this.Posts = Posts;
            this.CurrentUser = CurrentUser;
            this.users = users;
        }
        public string NuRoute;
       
        private void btnImage_Click(object sender, RoutedEventArgs e)
        { 
            
            
            // Create OpenFileDialog 
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            
            // Set filter for file extension and default file extension 
            dlg.DefaultExt = ".png";
            dlg.Filter = "JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif";
             
            // Display OpenFileDialog by calling ShowDialog method 
            Nullable<bool> result = dlg.ShowDialog();

            // Get the selected file name and display in a TextBox 
            if (result == true)
            {
                // Open document  

                //Filename = SourcePath

                string Target = @"..\..\MemeBase";
                string filename = dlg.FileName;

                //Testing Pushing.
                int j = BitConverter.ToInt32(Guid.NewGuid().ToByteArray(), 0);

                string NuRoute = Path.Combine(Target, j.ToString() + ".png");
                File.Copy(filename,  NuRoute);
                
                CurrentUser.createPost(txtDescription.Text, filename);
                ImageSourceConverter imgs = new ImageSourceConverter();
                imgMem.SetValue(Image.SourceProperty, imgs.ConvertFromString(NuRoute));
            }

        }

        // UI Fixes
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (verify) this.Owner.Show();

            string arregleObjects = JsonConvert.SerializeObject(users, Formatting.Indented);
            File.WriteAllText("data.Json", arregleObjects);
        }

        private void Imgranking_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            verify = false;
            Utils.Rankingwin(uploadwindow, Posts, CurrentUser, users);
        }

        private void Imghotornot_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            verify = false;
            Utils.HORN(uploadwindow, Posts, CurrentUser, users);
        }

        
    }
}
