﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace final
{
    /// <summary>
    /// Interaction logic for Ranking.xaml
    /// </summary>
    public partial class Ranking : Window
    {
       public bool verify = true;
        List<Post> Posts;
        User CurrentUser;
        List<User> users;
        public Ranking(List<Post> Posts, User CurrentUser, List<User> users)
        {
            InitializeComponent();
            this.Posts = Posts;
            this.CurrentUser = CurrentUser;
            this.users = users;
        }

        // UI Fixes
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (verify == true) this.Owner.Show();
        }

        private void Imghotnot_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            verify = false;
            Utils.HORN(rankingwindow, Posts, CurrentUser, users);   
        }

        private void Lblupload_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            verify = false;
            Utils.Uploadwin(rankingwindow, Posts, CurrentUser, users);
        }
    }
}
